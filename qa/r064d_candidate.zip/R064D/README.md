# R0.6.4D — integration candidate (NOT R90 qualification)

Do not unzip over main. Use a clean feature branch at the pinned commit.

```
git checkout 02c689fbcfdd946391842d2394376daf1216c6a6
git switch -c feature/r064d-integration
python /path/to/R064D/tools/integrate_r064d.py .
python /path/to/R064D/tools/integrate_r064d.py . --apply
OPENBLAS_NUM_THREADS=1 python -m unittest discover -s tests -v
streamlit run streamlit_app.py
```

See R064D_INTEGRATION_AND_CONSTITUTIVE_REPORT.md. No original SP PDFs, original Mathcad or Word client master included. The current GitHub main was not modified.
